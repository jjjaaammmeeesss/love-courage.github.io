import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import FamilyInfo from "@/pages/FamilyInfo";
import ParentAssessment from "@/pages/ParentAssessment";
import Results from "@/pages/Results";
import StoryAssessment from "@/pages/StoryAssessment";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';
import { AssessmentContext } from '@/contexts/assessmentContext';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [assessmentData, setAssessmentData] = useState({
    familyInfo: null,
    parentAssessment: null,
    storyAssessment: null
  });

  const logout = () => {
    setIsAuthenticated(false);
  };

  const saveFamilyInfo = (data) => {
    setAssessmentData(prev => ({ ...prev, familyInfo: data }));
    localStorage.setItem('familyInfo', JSON.stringify(data));
  };

  const saveParentAssessment = (data) => {
    setAssessmentData(prev => ({ ...prev, parentAssessment: data }));
    localStorage.setItem('parentAssessment', JSON.stringify(data));
  };
  

  const saveStoryAssessment = (data) => {
    setAssessmentData(prev => ({ ...prev, storyAssessment: data }));
    localStorage.setItem('storyAssessment', JSON.stringify(data));
  };
  
  


  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <AssessmentContext.Provider
        value={{ 
          assessmentData, 
          saveFamilyInfo, 
          saveParentAssessment, 
          saveStoryAssessment 
        }}
      >
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/family-info" element={<FamilyInfo />} />
          <Route path="/parent-assessment" element={<ParentAssessment />} />
          <Route path="/story-assessment" element={<StoryAssessment />} />
          <Route path="/results" element={<Results />} />
        </Routes>
      </AssessmentContext.Provider>
    </AuthContext.Provider>
  );
}
