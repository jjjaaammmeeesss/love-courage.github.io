import { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AssessmentContext } from '@/contexts/assessmentContext';

// Define all assessment dimensions
type Dimension = 
  | "father_goal"    // 父系：目标与动机
  | "father_control" // 父系：内控与担当
  | "father_logic"   // 父系：逻辑与决断
  | "father_rule"    // 父系：规则与边界
  | "mother_empathy" // 母系：共情力
  | "mother_nurture" // 母系：滋养力
  | "mother_tolerate"// 母系：包容力
  | "mother_repair"  // 母系：修复力
  | "self_centered"; // 自我中心化

// Story type definition
interface Story {
  id: number;
  title: string;
  introduction: string;
  sceneDescription: string; // 场景描述，用于生成图片
  interactions: Interaction[];
  conclusion: string;
}

interface Interaction {
  id: number;
  question: string;
  dimension: Dimension;
  options: InteractionOption[];
}

interface InteractionOption {
  id: string;
  text: string;
  imageDescription: string; // 选项图片描述
  level: 1 | 2 | 3; // 基础反应Lv1，进阶应对Lv2，策略升华Lv3
}

// 生成图片URL的工具函数
const generateImageUrl = (prompt: string) => {
  const encodedPrompt = encodeURIComponent(prompt);
  return `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%24%7BencodedPrompt%7D&sign=479fab6d6ff1e6fd0962eb9a4123a146`;
};

// 8 stories covering all 9 dimensions with picture book style images
const stories: Story[] = [
  {
    id: 1,
    title: "森林探险",
    introduction: "有一天，小明和朋友们一起去森林里探险。突然，他们遇到了一条湍急的河流挡住了去路...",
    sceneDescription: "Children's picture book style, a group of children encountering a river in a magical forest, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "面对河流，小明会怎么做？",
        dimension: "father_goal",
        sceneDescription: "Children's picture book style, a group of children facing a river in a magical forest, bright colors, cute characters, white background",
        options: [
          { 
            id: "A", 
            text: "立即尝试自己游泳过河", 
            level: 1,
            imageDescription: "Cartoon child trying to swim across a river, picture book style, white background"
          },
          { 
            id: "B", 
            text: "寻找安全的过河点并制定计划", 
            level: 2,
            imageDescription: "Cartoon child looking for a safe place to cross the river, picture book style, white background"
          },
          { 
            id: "C", 
            text: "分析河流情况，评估风险后再决定", 
            level: 3,
            imageDescription: "Cartoon child analyzing river conditions before deciding, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "过河时，发现有小伙伴看起来很害怕，小明会？",
        dimension: "mother_empathy",
        options: [
          { 
            id: "A", 
            text: "告诉小伙伴不要害怕，没什么好怕的", 
            level: 1,
            imageDescription: "Cartoon child telling friend not to be afraid, picture book style, white background"
          },
          { 
            id: "B", 
            text: "安慰小伙伴并牵着手一起过河", 
            level: 2,
            imageDescription: "Cartoon child comforting friend and holding hands to cross river, picture book style, white background"
          },
          { 
            id: "C", 
            text: "理解小伙伴的恐惧，提议休息一下再尝试", 
            level: 3,
            imageDescription: "Cartoon child understanding friend's fear and suggesting a rest, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "经过一番努力，小明和朋友们终于过河了，这次经历让他们学会了互相帮助的重要性。"
  },
  {
    id: 2,
    title: "班级活动",
    introduction: "五年级(3)班因自习课纪律涣散被全校通报批评。班主任王老师没有责备大家，而是宣布了一个特别决定：'从今天起，班级事务由你们自主管理，我们需要共同制定一份真正有效的班级公约。'消息传出，教室里立刻炸开了锅...",
    sceneDescription: "Classroom scene with children discussing, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "小组讨论时，大家意见不统一，小明会？",
        dimension: "father_rule",
        options: [
          { 
            id: "A", 
            text: "坚持按自己的想法做，认为自己的方案最好", 
            level: 1,
            imageDescription: "Cartoon child insisting on their own idea, picture book style, white background"
          },
          { 
            id: "B", 
            text: "提议大家遵守少数服从多数的原则做决定", 
            level: 2,
            imageDescription: "Cartoon child suggesting majority voting, picture book style, white background"
          },
          { 
            id: "C", 
            text: "引导大家制定明确的分工规则,确保公平合理", 
            level: 3,
            imageDescription: "Cartoon child leading group to create fair rules, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "活动中，有同学不小心打翻了食物，小明会？",
        dimension: "mother_tolerate",
        options: [
          { 
            id: "A", 
            text: "抱怨同学不小心，增加了大家的麻烦", 
            level: 1,
            imageDescription: "Cartoon child complaining about messy friend, picture book style, white background"
          },
          { 
            id: "B", 
            text: "安慰同学没关系，并帮忙清理", 
            level: 2,
            imageDescription: "Cartoon child comforting friend and helping clean up, picture book style, white background"
          },
          { 
            id: "C", 
            text: "理解意外难以避免，组织大家一起解决问题", 
            level: 3,
            imageDescription: "Cartoon child organizing group to solve problem together, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "虽然过程中有些小波折，但班级野餐活动最终圆满成功，大家都很开心。"
  },
  {
    id: 3,
    title: "团队比赛",
    introduction: "学校举办机器人比赛，小明作为队长带领团队参加...",
    sceneDescription: "Children building robots for competition, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "比赛前，团队成员练习不够认真，小明会？",
        dimension: "father_control",
        options: [
          { 
            id: "A", 
            text: "感到着急但不知道该怎么办", 
            level: 1,
            imageDescription: "Worried cartoon team captain, picture book style, white background"
          },
          { 
            id: "B", 
            text: "提醒大家要认真练习，否则会影响成绩", 
            level: 2,
            imageDescription: "Cartoon team captain reminding members to practice, picture book style, white background"
          },
          { 
            id: "C", 
            text: "分析原因，制定练习计划并带头执行", 
            level: 3,
            imageDescription: "Cartoon team captain creating practice schedule, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "有队员因为多次失败而想放弃，小明会？",
        dimension: "mother_nurture",
        options: [
          { 
            id: "A", 
            text: "告诉队员坚持下去，不能轻易放弃", 
            level: 1,
            imageDescription: "Cartoon captain telling teammate not to quit, picture book style, white background"
          },
          { 
            id: "B", 
            text: "鼓励队员，帮助分析失败原因", 
            level: 2,
            imageDescription: "Cartoon captain helping teammate analyze failure, picture book style, white background"
          },
          { 
            id: "C", 
            text: "肯定队员的努力，帮助他找到适合的角色和方法", 
            level: 3,
            imageDescription: "Cartoon captain helping teammate find suitable role, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "在小明的带领下，团队克服了困难，虽然没有获得冠军，但大家都收获了宝贵的经验。"
  },
  {
    id: 4,
    title: "朋友矛盾",
    introduction: "小明发现两个好朋友因为玩具问题吵架了，谁也不理谁...",
    sceneDescription: "Two children arguing over toys, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "面对朋友间的矛盾，小明会如何处理？",
        dimension: "father_logic",
        options: [
          { 
            id: "A", 
            text: "直接说应该分享玩具，让他们和好", 
            level: 1,
            imageDescription: "Cartoon child telling friends to share toys, picture book style, white background"
          },
          { 
            id: "B", 
            text: "了解吵架的原因，然后提出解决方案", 
            level: 2,
            imageDescription: "Cartoon child finding out why friends are arguing, picture book style, white background"
          },
          { 
            id: "C", 
            text: "先分开安抚两人，再引导他们理性沟通", 
            level: 3,
            imageDescription: "Cartoon child helping two friends communicate, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "经过调解，朋友仍然有些不开心，小明会？",
        dimension: "mother_repair",
        options: [
          { 
            id: "A", 
            text: "告诉他们别再生气了，过去的事就让它过去", 
            level: 1,
            imageDescription: "Cartoon child telling friends to stop being angry, picture book style, white background"
          },
          { 
            id: "B", 
            text: "提议一起做大家都喜欢的事情，转移注意力", 
            level: 2,
            imageDescription: "Cartoon child suggesting fun activity for friends, picture book style, white background"
          },
          { 
            id: "C", 
            text: "创造机会让他们互相表达歉意和理解", 
            level: 3,
            imageDescription: "Cartoon child helping friends apologize to each other, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "在小明的帮助下，两个好朋友终于和好了，他们都感谢小明的帮助。"
  },
  {
    id: 5,
    title: "社区服务",
    introduction: "学校开展\"敬老爱老\"主题月活动，组织五年级学生到社区养老院进行志愿服务。小明和其他9名同学被分配到三楼，负责帮助行动不便的老人打扫房间和整理物品...",
    sceneDescription: "Children helping elderly people in nursing home, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "分配任务时，小明被安排做最脏最累的活，他会？",
        dimension: "self_centered",
        options: [
          { 
            id: "A", 
            text: "不太情愿，尽量少做一点", 
            level: 1,
            imageDescription: "Reluctant child doing chores, picture book style, white background"
          },
          { 
            id: "B", 
            text: "虽然不情愿，但还是完成了任务", 
            level: 2,
            imageDescription: "Child completing difficult task, picture book style, white background"
          },
          { 
            id: "C", 
            text: "积极完成，并主动帮助其他同学", 
            level: 3,
            imageDescription: "Child actively helping others with chores, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "服务结束后，有位老人想感谢小明并送他小礼物，小明会？",
        dimension: "self_centered",
        options: [
          { 
            id: "A", 
            text: "很高兴地接受礼物并表示感谢", 
            level: 1,
            imageDescription: "Child happily accepting gift, picture book style, white background"
          },
          { 
            id: "B", 
            text: "婉拒礼物，但感谢老人的心意", 
            level: 2,
            imageDescription: "Child politely refusing gift, picture book style, white background"
          },
          { 
            id: "C", 
            text: "告诉老人帮助他人就是最好的礼物", 
            level: 3,
            imageDescription: "Child telling elderly person that helping is reward enough, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "通过这次社区服务，小明体会到了帮助他人的快乐，也明白了付出比索取更有意义。"
  },
  {
    id: 6,
    title: "家庭决策",
    introduction: "周末全家计划出游，但大家对去哪里玩有不同意见...",
    sceneDescription: "Family discussing vacation plans, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "小明有自己特别想去的地方，他会如何表达？",
        dimension: "father_goal",
        options: [
          { 
            id: "A", 
            text: "坚持要去自己想去的地方，否则就不去", 
            level: 1,
            imageDescription: "Child insisting on own preference, picture book style, white background"
          },
          { 
            id: "B", 
            text: "说出自己想去的理由，希望大家考虑", 
            level: 2,
            imageDescription: "Child explaining reasons for preferred destination, picture book style, white background"
          },
          { 
            id: "C", 
            text: "提出自己的想法，并了解家人的偏好后综合考虑", 
            level: 3,
            imageDescription: "Child discussing vacation options with family, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "妹妹因为没能去她想去的地方而不开心，小明会？",
        dimension: "mother_nurture",
        options: [
          { 
            id: "A", 
            text: "告诉妹妹别不高兴，这里也很好玩", 
            level: 1,
            imageDescription: "Child telling sad sister to cheer up, picture book style, white background"
          },
          { 
            id: "B", 
            text: "陪妹妹玩她喜欢的游戏，让她开心起来", 
            level: 2,
            imageDescription: "Child playing with sad sister, picture book style, white background"
          },
          { 
            id: "C", 
            text: "理解妹妹的感受，提议下次可以去她想去的地方", 
            level: 3,
            imageDescription: "Child comforting sister and making plans, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "虽然不是每个人都去了最想去的地方，但全家人还是度过了愉快的一天。"
  },
  {
    id: 7,
    title: "解决问题",
    introduction: "科学课上，小明小组需要完成一个复杂的实验，但实验一直不成功...",
    sceneDescription: "Children doing science experiment, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "面对实验失败，小明会怎么做？",
        dimension: "father_logic",
        options: [
          { 
            id: "A", 
            text: "觉得太难了，想放弃这个实验", 
            level: 1,
            imageDescription: "Child wanting to give up on science experiment, picture book style, white background"
          },
          { 
            id: "B", 
            text: "尝试按照课本重新操作一遍", 
            level: 2,
            imageDescription: "Child following textbook to redo experiment, picture book style, white background"
          },
          { 
            id: "C", 
            text: "分析失败原因，设计改进方案后再尝试", 
            level: 3,
            imageDescription: "Child analyzing experiment failure and planning improvements, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "小组中有人提出不同的实验方法，与小明的想法冲突，他会？",
        dimension: "mother_tolerate",
        options: [
          { 
            id: "A", 
            text: "坚持自己的方法，认为自己是对的", 
            level: 1,
            imageDescription: "Child insisting on own method, picture book style, white background"
          },
          { 
            id: "B", 
            text: "虽然不同意，但还是勉强同意尝试对方的方法", 
            level: 2,
            imageDescription: "Child reluctantly trying friend's method, picture book style, white background"
          },
          { 
            id: "C", 
            text: "认真听取对方的想法，找出两种方法的优点结合起来", 
            level: 3,
            imageDescription: "Child combining different ideas for experiment, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "经过多次尝试和改进，小明小组终于成功完成了实验，老师表扬了他们坚持不懈的精神。"
  },
  {
    id: 8,
    title: "意外事件",
    introduction: "在体育课上，小明不小心把篮球砸到了窗户，玻璃碎了...",
    sceneDescription: "Child breaking window with basketball, picture book style, bright colors, cute characters, white background",
    interactions: [
      {
        id: 1,
        question: "面对这种情况，小明的第一反应是？",
        dimension: "father_control",
        options: [
          { 
            id: "A", 
            text: "感到害怕，想赶紧离开现场", 
            level: 1,
            imageDescription: "Scared child wanting to run away, picture book style, white background"
          },
          { 
            id: "B", 
            text: "认识到自己的错误，主动告诉老师", 
            level: 2,
            imageDescription: "Child telling teacher about broken window, picture book style, white background"
          },
          { 
            id: "C", 
            text: "先确保没人受伤，然后报告老师并承担责任", 
            level: 3,
            imageDescription: "Responsible child reporting accident to teacher, picture book style, white background"
          }
        ]
      },
      {
        id: 2,
        question: "老师虽然原谅了小明，但需要赔偿玻璃，小明会？",
        dimension: "mother_repair",
        options: [
          { 
            id: "A", 
            text: "接受惩罚，但心里有些抱怨", 
            level: 1,
            imageDescription: "Child complaining about punishment, picture book style, white background"
          },
          { 
            id: "B", 
            text: "接受惩罚，并表示以后会更加小心", 
            level: 2,
            imageDescription: "Child accepting responsibility, picture book style, white background"
          },
          { 
            id: "C", 
            text: "主动提出通过劳动来弥补损失，并吸取教训", 
            level: 3,
            imageDescription: "Child offering to work to pay for damage, picture book style, white background"
          }
        ]
      }
    ],
    conclusion: "通过这件事，小明学会了勇于承担责任，也明白了做事要更加小心谨慎。"
  }
];

export default function StoryAssessment() {
  const navigate = useNavigate();
  const { saveStoryAssessment } = useContext(AssessmentContext);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [currentInteractionIndex, setCurrentInteractionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, {
    storyId: number;
    interactionId: number;
    dimension: Dimension;
    selectedOption: string;
    level: 1 | 2 | 3;
  }>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  
  // Get current story and interaction
  const currentStory = stories[currentStoryIndex];
  const currentInteraction = currentStory.interactions[currentInteractionIndex];
  
  // Calculate overall progress
  useEffect(() => {
    const totalInteractions = stories.reduce((total, story) => total + story.interactions.length, 0);
    const completedInteractions = Object.keys(answers).length;
    setProgress(Math.round((completedInteractions / totalInteractions) * 100));
  }, [answers]);
  
  const handleAnswerSelect = (optionId: string) => {
    // Find selected option
    const selectedOption = currentInteraction.options.find(opt => opt.id === optionId);
    if (!selectedOption) return;
    
    // Save answer
    setAnswers(prev => ({
      ...prev,
      [`${currentStory.id}-${currentInteraction.id}`]: {
        storyId: currentStory.id,
        interactionId: currentInteraction.id,
        dimension: currentInteraction.dimension,
        selectedOption: optionId,
        level: selectedOption.level
      }
    }));
    
    // Move to next interaction or story
    if (currentInteractionIndex < currentStory.interactions.length - 1) {
      // Next interaction in current story
      setCurrentInteractionIndex(prev => prev + 1);
    } else if (currentStoryIndex < stories.length - 1) {
      // Next story
      setCurrentStoryIndex(prev => prev + 1);
      setCurrentInteractionIndex(0);
    } else {
      // All stories completed
      submitAssessment();
    }
  };
  
  const submitAssessment = () => {
    setIsLoading(true);
    
    // Calculate dimension scores
    const dimensionScores: Record<Dimension, { total: number; count: number }> = {
      father_goal: { total: 0, count: 0 },
      father_control: { total: 0, count: 0 },
      father_logic: { total: 0, count: 0 },
      father_rule: { total: 0, count: 0 },
      mother_empathy: { total: 0, count: 0 },
      mother_nurture: { total: 0, count: 0 },
      mother_tolerate: { total: 0, count: 0 },
      mother_repair: { total: 0, count: 0 },
      self_centered: { total: 0, count: 0 }
    };
    
    // Aggregate scores by dimension
    Object.values(answers).forEach(answer => {
      dimensionScores[answer.dimension].total += answer.level;
      dimensionScores[answer.dimension].count += 1;
    });
    
    // Calculate average score for each dimension (1-3 scale)
    const dimensionAverages: Record<Dimension, number> = {} as Record<Dimension, number>;
    Object.entries(dimensionScores).forEach(([dimension, data]) => {
      dimensionAverages[dimension as Dimension] = data.count > 0 
        ? Math.round((data.total / data.count) * 10) / 10 
        : 0;
    });
    
    // Determine overall assessment type
    const fatherDimensions: Dimension[] = [
      "father_goal", "father_control", "father_logic", "father_rule"
    ];
    const motherDimensions: Dimension[] = [
      "mother_empathy", "mother_nurture", "mother_tolerate", "mother_repair"
    ];
    
    const fatherScore = fatherDimensions.reduce((sum, dim) => sum + dimensionAverages[dim], 0) / fatherDimensions.length;
    const motherScore = motherDimensions.reduce((sum, dim) => sum + dimensionAverages[dim], 0) / motherDimensions.length;
    
    const assessmentType = fatherScore / (fatherScore + motherScore) > 0.6 
      ? 'fatherStrong' 
      : motherScore / (fatherScore + motherScore) > 0.6 
        ? 'motherStrong' 
        : 'balanced';
    
    // Prepare result object
    const result = {
      answers,
      dimensionScores: dimensionAverages,
      fatherScore,
      motherScore,
      selfCenteredScore: dimensionAverages.self_centered,
      assessmentType,
      timestamp: new Date().toISOString()
    };
    
    // Save results
    saveStoryAssessment(result);
    
    // Simulate processing delay
    setTimeout(() => {
      setIsLoading(false);
      navigate('/results');
    }, 1500);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">AI故事智能评测</h1>
          <button 
            onClick={() => navigate('/')}
            className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
          >
            <i class="fa-solid fa-home mr-1"></i> 首页
          </button>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="max-w-3xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
           {/* Story Header */}
           <div className="bg-gradient-to-r from-green-500 to-teal-600 p-6 text-white">
             <div className="flex justify-between items-center">
               <h2 className="text-2xl font-bold">{currentStory.title}</h2>
               <span className="text-sm bg-white bg-opacity-20 px-3 py-1 rounded-full">
                 故事 {currentStoryIndex + 1}/{stories.length}
               </span>
             </div>
             <div className="mt-4 w-full bg-white bg-opacity-20 rounded-full h-2">
               <div 
                 className="bg-white h-2 rounded-full" 
                 style={{ width: `${progress}%` }}
               ></div>
             </div>
             <div className="flex justify-between items-center mt-1">
               <span className="text-sm">测评进度</span>
               <span className="text-sm font-medium">{progress}%</span>
             </div>
           </div>
           
           {/* Story Content */}
           <div className="p-6">
             {isLoading ? (
               <div className="text-center py-12">
                 <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500 mb-4"></div>
                 <h3 className="text-xl font-medium text-gray-900 dark:text-white">正在分析测评结果...</h3>
                 <p className="mt-2 text-gray-600 dark:text-gray-400">
                   我们正在根据孩子的选择评估9个维度的心理特质
                 </p>
               </div>
             ) : (
                <>
                  {/* Story Scene Image */}
                  <div className="mb-8 flex justify-center">
                    <div className="relative w-full max-w-md aspect-square rounded-xl overflow-hidden shadow-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                      {currentInteraction.sceneDescription && (
                        <img
                          src={generateImageUrl(currentInteraction.sceneDescription)}
                          alt={`Scene for interaction ${currentInteraction.id} in ${currentStory.title}`}
                          className="w-full h-full object-contain p-4"
                        />
                      )}
                      <div className="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                        故事场景
                      </div>
                    </div>
                  </div>
                  
                  {/* Story Introduction */}
                  <div className="prose dark:prose-invert max-w-none mb-8">
                    <p>{currentStory.introduction}</p>
                  </div>
                 
                  <div className="bg-gray-50 dark:bg-gray-700 p-5 rounded-lg mb-8">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                      {currentInteraction.question}
                    </h3>
                    <div className="space-y-6">
                      {currentInteraction.options.map(option => (
                        <button
                          key={option.id}
                          onClick={() => handleAnswerSelect(option.id)}
                          className="w-full text-left p-4 border border-gray-200 dark:border-gray-600 rounded-xl hover:shadow-md transition-all bg-white dark:bg-gray-800"
                        >
                          <div className="flex flex-col sm:flex-row gap-4">
                            {/* Option Image */}

                            
                            {/* Option Text */}
                            <div className="flex-1 flex flex-col justify-center">
                              <div className="flex items-center">
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300 font-medium mr-3">
                                  {option.id}
                                </span>
                                <span>{option.text}</span>
                              </div>
                              <span className="ml-9 mt-1 text-xs text-gray-500 dark:text-gray-400">
                                {option.level === 1 ? '基础反应' : option.level === 2 ? '进阶应对' : '策略升华'}
                              </span>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                 
                 <div className="flex justify-between">
                   <button
                     onClick={() => {
                       if (currentInteractionIndex > 0) {
                         setCurrentInteractionIndex(prev => prev - 1);
                       } else if (currentStoryIndex > 0) {
                         const prevStory = stories[currentStoryIndex - 1];
                         setCurrentStoryIndex(prev => prev - 1);
                         setCurrentInteractionIndex(prevStory.interactions.length - 1);
                       } else {
                         navigate('/parent-assessment');
                       }
                     }}
                     className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                   >
                     <i class="fa-solid fa-arrow-left mr-2"></i> 
                     {currentStoryIndex === 0 && currentInteractionIndex === 0 
                       ? '返回上一步' 
                       : '上一题'}
                   </button>
                   
                   <button
                     onClick={() => navigate('/')}
                     className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                   >
                     退出测评
                   </button>
                 </div>
               </>
             )}
           </div>
        </div>
      </main>
    </div>
  );
}