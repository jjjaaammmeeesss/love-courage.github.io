import { useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AssessmentContext } from '@/contexts/assessmentContext';
import { 
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, PieChart, Pie, Cell 
} from 'recharts';

// Radar chart data formatter
const formatRadarData = (assessmentData) => {
  // Mock data generation since we don't have the actual algorithm
  return [
    { subject: '目标与动机', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '内控与担当', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '逻辑与决断', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '规则与边界', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '共情力', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '滋养力', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '包容力', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
    { subject: '修复力', A: Math.floor(Math.random() * 3) + 1, fullMark: 3 },
  ];
};

// Pie chart data for family influence
const getFamilyInfluenceData = () => {
  return [
    { name: '父系力量', value: Math.floor(Math.random() * 50) + 30 },
    { name: '母系力量', value: Math.floor(Math.random() * 50) + 30 },
  ];
};

// Bar chart data for comparison
const getComparisonData = () => {
  return [
    { name: '目标与动机', 孩子: Math.floor(Math.random() * 3) + 1, 父母自评: Math.floor(Math.random() * 3) + 1 },
    { name: '规则与边界', 孩子: Math.floor(Math.random() * 3) + 1, 父母自评: Math.floor(Math.random() * 3) + 1 },
    { name: '共情力', 孩子: Math.floor(Math.random() * 3) + 1, 父母自评: Math.floor(Math.random() * 3) + 1 },
    { name: '包容力', 孩子: Math.floor(Math.random() * 3) + 1, 父母自评: Math.floor(Math.random() * 3) + 1 },
  ];
};

// Color palette
const COLORS = ['#3b82f6', '#ec4899', '#10b981', '#f59e0b', '#8b5cf6'];

export default function Results() {
  const navigate = useNavigate();
  const { assessmentData } = useContext(AssessmentContext);
  const [radarData, setRadarData] = useState([]);
  const [familyInfluenceData, setFamilyInfluenceData] = useState([]);
  const [comparisonData, setComparisonData] = useState([]);
  const [assessmentType, setAssessmentType] = useState('balanced');
  const [isLoading, setIsLoading] = useState(true);

  // Calculate assessment results
  // Calculate child type based on assessment data
  const getChildTypeId = () => {
    const { fatherScore = 0, motherScore = 0, selfCenteredScore = 0 } = assessmentData.storyAssessment || {};
    
    if (fatherScore > 2.5 && motherScore > 2.5 && selfCenteredScore > 1.5 && selfCenteredScore < 2.5) {
      return 1; // Balanced
    } else if (fatherScore > 2.5 && motherScore < 1.5 && selfCenteredScore > 2.5) {
      return 2; // Self-righteous
    } else if (fatherScore < 1.5 && motherScore > 2.5 && selfCenteredScore > 2.5) {
      return 3; // Externally dependent
    } else if (fatherScore > 2.5 && motherScore < 1.5 && selfCenteredScore < 1.5) {
      return 4; // Self-critical
    } else if (fatherScore < 1.5 && motherScore > 2.5 && selfCenteredScore < 1.5) {
      return 5; // Self-neglecting
    } else if (fatherScore < 1.5 && motherScore < 1.5) {
      return 6; // Neglecting
    }
    return 1; // Default to balanced
  };

  // Get child type info
  const childTypeId = getChildTypeId();
  const childTypes = [
    { id: 1, name: "均衡型" },
    { id: 2, name: "自以为是型" },
    { id: 3, name: "外求依赖型" },
    { id: 4, name: "自我苛责型" },
    { id: 5, name: "自我忽视型" },
    { id: 6, name: "忽视型" }
  ];
  const childType = childTypes.find(type => type.id === childTypeId) || childTypes[0];

  useEffect(() => {
    // Simulate loading delay
    setTimeout(() => {
      // Generate mock results based on available data
      setRadarData(formatRadarData(assessmentData));
      setFamilyInfluenceData(getFamilyInfluenceData());
      setComparisonData(getComparisonData());
      
      // Determine assessment type based on mock data
      const fatherValue = familyInfluenceData[0]?.value || 0;
      const motherValue = familyInfluenceData[1]?.value || 0;
      
      if (fatherValue / (fatherValue + motherValue) > 0.6) {
        setAssessmentType('fatherStrong');
      } else if (motherValue / (fatherValue + motherValue) > 0.6) {
        setAssessmentType('motherStrong');
      } else {
        setAssessmentType('balanced');
      }
      
      setIsLoading(false);
    }, 1500);
  }, [assessmentData]);

  // Get recommendations based on assessment type
  const getRecommendations = () => {
    switch (assessmentType) {
      case 'fatherStrong':
        return [
          "增加情感表达和沟通的机会，鼓励孩子分享内心感受",
          "提供更多创造性和艺术性活动，培养孩子的想象力",
          "引导孩子关注他人需求，培养同理心和关怀能力",
          "在规则和成就之外，强调合作与团队精神的重要性"
        ];
      case 'motherStrong':
        return [
          "设置适当的挑战和目标，培养孩子的成就动机",
          "建立明确的规则和界限，培养责任感和自律性",
          "鼓励独立解决问题，增强自信心和决断能力",
          "提供竞争性活动，教导如何优雅地获胜和接受失败"
        ];
      default: // balanced
        return [
          "继续保持当前的平衡教育方式",
          "根据孩子的兴趣和特长提供针对性的发展机会",
          "鼓励孩子在不同情境中灵活运用不同的思维方式",
          "培养孩子的多元智能和综合能力"
        ];
    }
  };

  // Get assessment description based on type
  const getAssessmentDescription = () => {
    switch (assessmentType) {
      case 'fatherStrong':
        return "您的孩子表现出较强的父系力量倾向，更注重成就、规则和独立性。这类孩子通常目标明确，有较强的自律性和责任感，但可能需要加强情感表达和同理心方面的发展。";
      case 'motherStrong':
        return "您的孩子表现出较强的母系力量倾向，更注重关系、包容和合作。这类孩子通常善于沟通，富有同情心，能够与他人建立良好的关系，但可能需要加强目标设定和规则意识方面的发展。";
      default: // balanced
        return "您的孩子表现出平衡的父系母系力量倾向，能够根据不同情境灵活运用不同的思维方式和行为策略。这类孩子通常适应性强，在个人成就和人际关系方面都能表现良好。";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mb-4"></div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">正在生成评估报告</h2>
          <p className="mt-2 text-gray-600 dark:text-gray-400 max-w-md mx-auto">
            我们正在分析您的家族信息、自评结果和故事互动数据，生成个性化的家族力量评估报告
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8 sticky top-0 bg-white dark:bg-gray-900 shadow-sm z-10">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">家族力量评估报告</h1>
          <div className="flex space-x-4">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              <i class="fa-solid fa-print mr-1"></i> 打印报告
            </button>
            <button 
              onClick={() => navigate('/')}
              className="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              <i class="fa-solid fa-home mr-1"></i> 返回首页
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* Assessment Summary */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white">孩子家族力量评估结果</h2>
              <p className="mt-2 text-gray-600 dark:text-gray-400">
                评估日期: {new Date().toLocaleDateString()}
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <div className={`inline-flex items-center px-4 py-2 rounded-full text-lg font-semibold ${
                childTypeId === 6
                  ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                  : childTypeId === 1
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                    : childTypeId === 2 || childTypeId === 4
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
                      : 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300'
              }`}>
                {childTypes.find(type => type.id === childTypeId)?.name || '未确定类型'}
              </div>
            </div>
          </div>

          <div className="prose dark:prose-invert max-w-none">
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
              {getAssessmentDescription()}
            </p>
          </div>
        </div>

        {/* Child Development Type Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8 mb-8">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            孩子的力量发育类型
          </h3>
          
          {/* Determine child type based on assessment data */}
          {(() => {
            // Define the six child types
            const childTypes = [
              {
                id: 1,
                name: "均衡型",
                description: "父强母强+爱人爱己",
                interventionDirection: "强化细分维度、定向培养特长",
                interventionGoal: "培养合作与责任感"
              },
              {
                id: 2,
                name: "自以为是型",
                description: "父母母弱+爱自己",
                interventionDirection: "化解父系、补充母系",
                interventionGoal: "学习共情与柔性沟通"
              },
              {
                id: 3,
                name: "外求依赖型",
                description: "父弱母强+爱自己",
                interventionDirection: "化解母系、补充父系",
                interventionGoal: "建立规则与延迟满足"
              },
              {
                id: 4,
                name: "自我苛责型",
                description: "父强母弱+爱他人",
                interventionDirection: "化解父系、补充母系",
                interventionGoal: "学会爱自己，滋养自己"
              },
              {
                id: 5,
                name: "自我忽视型",
                description: "父弱母强+爱他人",
                interventionDirection: "化解母系、补充父系",
                interventionGoal: "学会守护自己，会说不"
              },
              {
                id: 6,
                name: "忽视型",
                description: "父弱母弱+不爱人不爱己",
                interventionDirection: "既补充父系、也补充母系",
                interventionGoal: "激发情感表达与主动性"
              }
            ];
            
            // Determine child type based on scores
            // Get scores from assessment data
            const { fatherScore = 0, motherScore = 0, selfCenteredScore = 0 } = assessmentData.storyAssessment || {};
            
            let childTypeId = 1; // Default to balanced type
            
            // Simplified logic to determine type based on scores
            // In a real application, this would be based on more sophisticated calculations
            if (fatherScore > 2.5 && motherScore > 2.5 && selfCenteredScore > 1.5 && selfCenteredScore < 2.5) {
              childTypeId = 1; // Balanced
            } else if (fatherScore > 2.5 && motherScore < 1.5 && selfCenteredScore > 2.5) {
              childTypeId = 2; // Self-righteous
            } else if (fatherScore < 1.5 && motherScore > 2.5 && selfCenteredScore > 2.5) {
              childTypeId = 3; // Externally dependent
            } else if (fatherScore > 2.5 && motherScore < 1.5 && selfCenteredScore < 1.5) {
              childTypeId = 4; // Self-critical
            } else if (fatherScore < 1.5 && motherScore > 2.5 && selfCenteredScore < 1.5) {
              childTypeId = 5; // Self-neglecting
            } else if (fatherScore < 1.5 && motherScore < 1.5) {
              childTypeId = 6; // Neglecting
            }
            
            return (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        类型
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        力量维度
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        干预方向
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        干预目标
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {childTypes.map((type) => (
                      <tr key={type.id} className={type.id === childTypeId ? "bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500" : ""}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center mr-3">
                              <span className="text-sm font-medium text-gray-900 dark:text-white">{type.id}</span>
                            </div>
                            <div>
                              <div className="text-sm font-medium text-gray-900 dark:text-white">{type.name}</div>
                              {type.id === childTypeId && (
                                <div className="text-xs font-medium text-blue-600 dark:text-blue-400">您孩子的类型</div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                          {type.description}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                          {type.interventionDirection}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                          {type.interventionGoal}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })()}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Radar Chart */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
              父系母系力量雷达图
            </h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                  <PolarGrid stroke="#ccc" />
                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 3]} tick={{ fontSize: 10 }} />
                  <Radar
                    name="力量水平"
                    dataKey="A"
                    stroke="#3b82f6"
                    fill="#3b82f6"
                    fillOpacity={0.6}
                  />
                  <Tooltip 
                    formatter={(value) => [`Level ${value}`, '力量水平']}
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                      border: 'none'
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
              <p>评估维度：1-3分（1=基础反应，2=进阶应对，3=策略升华）</p>
            </div>
          </div>

          {/* Family Influence Pie Chart */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
              家族力量影响占比
            </h3>
            <div className="h-80 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%" maxWidth={300}>
                <PieChart>
                  <Pie
                    data={familyInfluenceData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {familyInfluenceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, '影响力占比']}
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                      border: 'none'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Comparison Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
            孩子与父母自评对比
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={comparisonData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis domain={[0, 3]} ticks={[1, 2, 3]} />
                <Tooltip 
                  formatter={(value) => [`Level ${value}`, '力量水平']}
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                    borderRadius: '8px',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                    border: 'none'
                  }}
                />
                <Legend />
                <Bar dataKey="孩子" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="父母自评" fill="#ec4899" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recommendations Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8 mb-8">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">
            个性化发展建议
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            {getRecommendations().map((recommendation, index) => (
              <div key={index} className="flex">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mt-0.5">
                  <span className="text-blue-600 dark:text-blue-300 text-xs font-medium">{index + 1}</span>
                </div>
                <p className="ml-4 text-gray-700 dark:text-gray-300">{recommendation}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
            <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">后续建议</h4>
            <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
              <li>每3个月进行一次复测，跟踪孩子的家族力量发展变化</li>
              <li>根据评估结果，选择适合的干预活动和故事内容</li>
              <li>父母可以参与相关的家族力量提升课程，优化家庭教育方式</li>
              <li>鼓励家族成员共同参与评估，形成更全面的家族力量图谱</li>
            </ul>
          </div>
        </div>

        {/* Next Steps */}
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900 dark:to-purple-900 rounded-xl p-6 sm:p-8 mb-8">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
            下一步行动计划
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-sm">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mb-4">
                <i class="fa-solid fa-book text-blue-600 dark:text-blue-400 text-xl"></i>
              </div>
              <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">推荐故事</h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                根据评估结果，系统推荐了5个适合孩子当前发展阶段的干预故事
              </p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-sm">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mb-4">
                <i class="fa-solid fa-gamepad text-green-600 dark:text-green-400 text-xl"></i>
              </div>
              <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">互动活动</h4>
              <p className="text-gray->600 dark:text-gray-400 text-sm">
                8个针对性的亲子互动活动，帮助平衡和发展孩子的家族力量
              </p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-sm">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mb-4">
                <i class="fa-solid fa-calendar-alt text-purple-600 dark:text-purple-400 text-xl"></i>
              </div>
              <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-2">定期复测</h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                预约3个月后的复测，跟踪孩子的家族力量发展变化
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              家族力量测评系统 © {new Date().getFullYear()} - 本报告仅供参考，不构成专业教育建议
            </p>
            <p className="text-gray-400 dark:text-gray-500 text-xs mt-2">
              数据更新时间: {new Date().toLocaleString()}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}