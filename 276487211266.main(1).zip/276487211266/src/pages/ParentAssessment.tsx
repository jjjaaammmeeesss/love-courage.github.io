import { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AssessmentContext } from '@/contexts/assessmentContext';

// Questionnaire data
const questionnaires = {
  parentSelfAssessment: [
    {
      id: 1,
      question: '我倾向于为孩子设定明确的目标和期望',
      dimension: 'father',
      subdimension: 'goalSetting'
    },
    {
      id: 2,
      question: '我善于倾听孩子的情感需求',
      dimension: 'mother',
      subdimension: 'empathy'
    },
    {
      id: 3,
      question: '我重视家庭规则的建立和执行',
      dimension: 'father',
      subdimension: 'ruleSetting'
    },
    {
      id: 4,
      question: '我倾向于包容孩子的错误并帮助他们从中学习',
      dimension: 'mother',
      subdimension: 'tolerance'
    },
    {
      id: 5,
      question: '我鼓励孩子独立解决问题',
      dimension: 'father',
      subdimension: 'independence'
    },
    {
      id: 6,
      question: '我重视与孩子建立情感连接',
      dimension: 'mother',
      subdimension: 'connection'
    }
  ],
  childAssessment: [
    {
      id: 7,
      question: '我的孩子倾向于遵守规则和秩序',
      dimension: 'father',
      subdimension: 'ruleFollowing'
    },
    {
      id: 8,
      question: '我的孩子善于理解他人的感受',
      dimension: 'mother',
      subdimension: 'empathy'
    },
    {
      id: 9,
      question: '我的孩子有较强的成就动机',
      dimension: 'father',
      subdimension: 'achievement'
    },
    {
      id: 10,
      question: '我的孩子善于与他人建立友谊和合作',
      dimension: 'mother',
      subdimension: 'sociability'
    },
    {
      id: 11,
      question: '我的孩子面对困难时表现出坚韧不拔的品质',
      dimension: 'father',
      subdimension: 'resilience'
    },
    {
      id: 12,
      question: '我的孩子在团队中表现出关怀他人的行为',
      dimension: 'mother',
      subdimension: 'caring'
    }
  ]
};

// Response options
const responseOptions = [
  { id: 1, label: '完全不符合' },
  { id: 2, label: '不太符合' },
  { id: 3, label: '一般' },
  { id: 4, label: '比较符合' },
  { id: 5, label: '完全符合' }
];

export default function ParentAssessment() {
  const navigate = useNavigate();
  const { saveParentAssessment } = useContext(AssessmentContext);
  const [activeSection, setActiveSection] = useState('self');
  const [responses, setResponses] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  // Load saved data from localStorage if available
  useEffect(() => {
    const savedData = localStorage.getItem('parentAssessment');
    if (savedData) {
      const parsedData = JSON.parse(savedData);
      setResponses(parsedData);
      updateProgress(parsedData);
    }
  }, []);

  // Calculate progress
  const updateProgress = (data) => {
    const totalQuestions = questionnaires.parentSelfAssessment.length + questionnaires.childAssessment.length;
    const answeredQuestions = Object.keys(data).length;
    setProgress(Math.round((answeredQuestions / totalQuestions) * 100));
  };

  // Handle response change
  const handleResponseChange = (questionId, value) => {
    const newResponses = { ...responses, [questionId]: parseInt(value) };
    setResponses(newResponses);
    updateProgress(newResponses);
  };

  // Validate current section
  const validateSection = () => {
    const questions = activeSection === 'self' 
      ? questionnaires.parentSelfAssessment 
      : questionnaires.childAssessment;
    
    return questions.every(q => responses[q.id] !== undefined);
  };

  // Handle section navigation
  const handleSectionNavigation = (direction) => {
    if (direction === 'next' && !validateSection()) {
      alert('请完成当前部分的所有问题后再继续');
      return;
    }
    
    if (direction === 'next') {
      setActiveSection('child');
    } else {
      setActiveSection('self');
    }
  };

  // Handle form submission
  const handleSubmit = () => {
    if (!validateSection()) {
      alert('请完成所有问题后再提交');
      return;
    }
    
    setIsLoading(true);
    
    // Prepare data for saving
    const assessmentData = {
      selfAssessment: questionnaires.parentSelfAssessment.map(q => ({
        questionId: q.id,
        dimension: q.dimension,
        subdimension: q.subdimension,
        response: responses[q.id]
      })),
      childAssessment: questionnaires.childAssessment.map(q => ({
        questionId: q.id,
        dimension: q.dimension,
        subdimension: q.subdimension,
        response: responses[q.id]
      })),
      timestamp: new Date().toISOString()
    };
    
    // Save data
    saveParentAssessment(assessmentData);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      navigate('/story-assessment');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">父母自评</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              进度: {progress}%
            </span>
            <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {activeSection === 'self' ? '父母自测问卷' : '孩子评估问卷'}
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              {activeSection === 'self' 
                ? '请根据您的实际情况，对以下描述进行评价' 
                : '请根据您对孩子的观察，对以下描述进行评价'}
            </p>
          </div>

          {/* Section Tabs */}
          <div className="mb-8 border-b border-gray-200 dark:border-gray-700">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveSection('self')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeSection === 'self'
                    ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                父母自测
              </button>
              <button
                onClick={() => setActiveSection('child')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeSection === 'child'
                    ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                孩子评估
              </button>
            </nav>
          </div>

          {/* Questionnaire */}
          <div className="space-y-8">
            {activeSection === 'self' 
              ? questionnaires.parentSelfAssessment.map(question => (
                  <div key={question.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-6 hover:shadow-md transition-shadow">
                    <div className="mb-4">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        {question.id}. {question.question}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        {question.dimension === 'father' ? '父系力量' : '母系力量'} - {question.subdimension}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {responseOptions.map(option => (
                        <label
                          key={option.id}
                          className={`inline-flex items-center px-4 py-2 rounded-md cursor-pointer transition-colors ${
                            responses[question.id] === option.id
                              ? question.dimension === 'father' 
                                ? 'bg-blue bg-opacity-10 border-blue-300 dark:border-blue-700 dark:bg-blue-900 dark:bg-opacity-20' 
                                : 'bg-pink bg-opacity-10 border-pink-300 dark:border-pink-700 dark:bg-pink-900 dark:bg-opacity-20'
                              : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`question_${question.id}`}
                            value={option.id}
                            checked={responses[question.id] === option.id}  
                            onChange={(e) => handleResponseChange(question.id, e.target.value)}
                            className="sr-only"
                          />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {option.label}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))
              : questionnaires.childAssessment.map(question => (
                  <div key={question.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-6 hover:shadow-md transition-shadow">
                    <div className="mb-4">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        {question.id}. {question.question}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        {question.dimension === 'father' ? '父系力量' : '母系力量'} - {question.subdimension}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {responseOptions.map(option => (
                        <label
                          key={option.id}
                          className={`inline-flex items-center px-4 py-2 rounded-md cursor-pointer transition-colors ${
                            responses[question.id] === option.id
                              ? question.dimension === 'father' 
                                ? 'bg-blue bg-opacity-10 border-blue-300 dark:border-blue-700 dark:bg-blue-900 dark:bg-opacity-20' 
                                : 'bg-pink bg-opacity-10 border-pink-300 dark:border-pink-700 dark:bg-pink-900 dark:bg-opacity-20'
                              : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`question_${question.id}`}
                            value={option.id}
                            checked={responses[question.id] === option.id}
                            onChange={(e) => handleResponseChange(question.id, e.target.value)}
                            className="sr-only"
                          />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {option.label}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between pt-8 border-t border-gray-200 dark:border-gray-700">
            {activeSection === 'self' ? (
              <button
                type="button"
                onClick={() => navigate('/family-info')}
                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <i class="fa-solid fa-arrow-left mr-2"></i> 返回家族信息
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleSectionNavigation('prev')}
                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <i class="fa-solid fa-arrow-left mr-2"></i> 上一部分：父母自测
              </button>
            )}

            {activeSection === 'self' ? (
              <button
                type="button"
                onClick={() => handleSectionNavigation('next')}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
              >
                下一部分：孩子评估
                <i class="fa-solid fa-arrow-right ml-2"></i>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={isLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <i class="fa-solid fa-spinner fa-spin mr-2"></i> 提交中...
                  </>
                ) : (
                  <>
                    完成测评，进入故事评估
                    <i class="fa-solid fa-arrow-right ml-2"></i>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}