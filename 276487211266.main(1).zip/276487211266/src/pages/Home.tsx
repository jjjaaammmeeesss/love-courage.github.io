import { Link } from "react-router-dom";
import { useContext } from "react";
import { AssessmentContext } from '@/contexts/assessmentContext';

export default function Home() {
  const { assessmentData } = useContext(AssessmentContext);
  
  // Determine progress based on completed sections
  const progress = Object.values(assessmentData).filter(data => data !== null).length / 3 * 100;
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">家族力量测评系统</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              进度: {Math.round(progress)}%
            </span>
            <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl">
              探索家族力量，助力孩子成长
            </h2>
             <p className="mt-4 max-w-2xl text-xl text-gray-500 dark:text-gray-400 mx-auto">
               通过科学评估、了解家族父系母系力量传承，为孩子的心智全面发展提供个性化指导
            </p>
          </div>

          {/* Assessment Steps */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1: Family Information */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105">
              <div className="h-48 bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                <i class="fa-solid fa-users text-6xl text-blue-600 dark:text-blue-300"></i>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">家族基础信息</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  输入家庭结构数据，建立家族父系母系力量纵向传导图
                </p>
                <Link
                  to="/family-info"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
                >
                  开始填写
                  <i class="fa-solid fa-arrow-right ml-2"></i>
                </Link>
              </div>
            </div>

            {/* Step 2: Parent Assessment */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105">
              <div className="h-48 bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                <i class="fa-solid fa-clipboard-check text-6xl text-purple-600 dark:text-purple-300"></i>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">父母自评</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  完成父系和母系力量问卷，评估自身及孩子的家族力量特质
                </p>
                <Link
                  to="/parent-assessment"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700"
                >
                  开始测评
                  <i class="fa-solid fa-arrow-right ml-2"></i>
                </Link>
              </div>
            </div>

            {/* Step 3: Story Assessment */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105">
              <div className="h-48 bg-green-100 dark:bg-green-900 flex items-center justify-center">
                <i class="fa-solid fa-book-open text-6xl text-green-600 dark:text-green-300"></i>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">AI故事智能评测</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  通过AI生成的互动故事，评估孩子的父系母系力量发展情况
                </p>
                <Link
                  to="/story-assessment"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700"
                >
                  开始故事
                  <i class="fa-solid fa-arrow-right ml-2"></i>
                </Link>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="mt-12 text-center">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">查看测评结果</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
              完成所有测评后，查看详细的家族力量分析报告和个性化发展建议
            </p>
            <Link
              to="/results"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
            >
              查看结果分析
              <i class="fa-solid fa-chart-radar ml-2"></i>
            </Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500 dark:text-gray-400">
            © {new Date().getFullYear()} 家族力量测评系统 - 助力每一个孩子的健康成长
          </p>
        </div>
      </footer>
    </div>
  );
}