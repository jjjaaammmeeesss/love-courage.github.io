import { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AssessmentContext } from '@/contexts/assessmentContext';

// Family structure options
const familyStructureOptions = [
  { id: 'nuclear', label: '核心家庭（父母+子女）' },
  { id: 'single-parent', label: '单亲家庭' },
  { id: 'grandparent', label: '隔代抚养' },
  { id: 'left-behind', label: '留守儿童' },
  { id: 'extended', label: '三代共居' },
  { id: 'other', label: '其他' }
];

// Family member type options
const familyMemberTypes = [
  { id: 'grandfather_p', label: '祖父（父系）' },
  { id: 'grandmother_p', label: '祖母（父系）' },
  { id: 'grandfather_m', label: '外祖父（母系）' },
  { id: 'grandmother_m', label: '外祖母（母系）' },
  { id: 'father', label: '父亲' },
  { id: 'mother', label: '母亲' },
  { id: 'child', label: '孩子' },
  { id: 'other', label: '其他' }
];

export default function FamilyInfo() {
  const navigate = useNavigate();
  const { saveFamilyInfo } = useContext(AssessmentContext);
  const [formData, setFormData] = useState({
    familyStructure: '',
    generations: 3,
    members: [
      { id: 1, name: '', type: '', gender: 'male', age: '' }
    ],
    siblings: {
      count: 1,
      genders: ['male']
    }
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  // Load saved data from localStorage if available
  useEffect(() => {
    const savedData = localStorage.getItem('familyInfo');
    if (savedData) {
      setFormData(JSON.parse(savedData));
    }
  }, []);

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Handle member changes
  const handleMemberChange = (id, field, value) => {
    setFormData(prev => ({
      ...prev,
      members: prev.members.map(member => 
        member.id === id ? { ...member, [field]: value } : member
      )
    }));
  };

  // Add new family member
  const addMember = () => {
    const newId = Math.max(...formData.members.map(m => m.id)) + 1;
    setFormData(prev => ({
      ...prev,
      members: [...prev.members, { id: newId, name: '', type: '', gender: 'male', age: '' }]
    }));
  };

  // Remove family member
  const removeMember = (id) => {
    if (formData.members.length > 1) {
      setFormData(prev => ({
        ...prev,
        members: prev.members.filter(member => member.id !== id)
      }));
    }
  };

  // Handle siblings count change
  const handleSiblingsCountChange = (e) => {
    const count = parseInt(e.target.value);
    const genders = Array(count).fill('male');
    setFormData(prev => ({
      ...prev,
      siblings: { ...prev.siblings, count, genders }
    }));
  };

  // Handle sibling gender change
  const handleSiblingGenderChange = (index, value) => {
    const genders = [...formData.siblings.genders];
    genders[index] = value;
    setFormData(prev => ({
      ...prev,
      siblings: { ...prev.siblings, genders }
    }));
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.familyStructure) {
      newErrors.familyStructure = '请选择家庭结构';
    }
    
    formData.members.forEach((member, index) => {
      if (!member.name) {
        newErrors[`memberName_${member.id}`] = '请输入成员姓名';
      }
      if (!member.type) {
        newErrors[`memberType_${member.id}`] = '请选择成员类型';
      }
      if (!member.age) {
        newErrors[`memberAge_${member.id}`] = '请输入成员年龄';
      }
    });
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      setIsLoading(true);
      
      // Save data
      saveFamilyInfo(formData);
      
      // Simulate API call
      setTimeout(() => {
        setIsLoading(false);
        navigate('/parent-assessment');
      }, 1000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">家族基础信息</h1>
          <button 
            onClick={() => navigate('/')}
            className="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
          >
            <i class="fa-solid fa-home mr-1"></i> 首页
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 sm:p-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">家族结构信息采集</h2>
            <p className="text-gray-600 dark:text-gray-300">
              请填写您的家庭结构信息，这将帮助我们构建家族力量传导图
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Family Structure */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                家庭结构类型 <span className="text-red-500">*</span>
              </label>
              <select
                name="familyStructure"
                value={formData.familyStructure}
                onChange={handleChange}
                className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:text-white"
              >
                <option value="">请选择家庭结构</option>
                {familyStructureOptions.map(option => (
                  <option key={option.id} value={option.id}>
                    {option.label}
                  </option>
                ))}
              </select>
              {errors.familyStructure && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.familyStructure}</p>
              )}
            </div>

            {/* Generations */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                向上追溯代数
              </label>
              <select
                name="generations"
                value={formData.generations}
                onChange={handleChange}
                className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:text-white"
              >
                <option value="1">1代</option>
                <option value="2">2代</option>
                <option value="3">3代</option>
                <option value="4">4代</option>
              </select>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                系统默认向上追溯3代人（家长一代、家长的父母一代）
              </p>
            </div>

            {/* Family Members */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  家庭成员信息 <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={addMember}
                  className="inline-flex items-center px-3 py-1 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <i class="fa-solid fa-plus mr-1"></i> 添加成员
                </button>
              </div>

              {formData.members.map((member, index) => (
                <div key={member.id} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        姓名 <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        name={`memberName_${member.id}`}
                        value={member.name}
                        onChange={(e) => handleMemberChange(member.id, 'name', e.target.value)}
                        className="block w-full pl-3 pr-3 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:text-white"
                      />
                      {errors[`memberName_${member.id}`] && (
                        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors[`memberName_${member.id}`]}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        成员类型 <span className="text-red-500">*</span>
                      </label>
                      <select
                        name={`memberType_${member.id}`}
                        value={member.type}
                        onChange={(e) => handleMemberChange(member.id, 'type', e.target.value)}
                        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:text-white"
                      >
                        <option value="">请选择</option>
                        {familyMemberTypes.map(option => (
                          <option key={option.id} value={option.id}>
                            {option.label}
                          </option>
                        ))}
                      </select>
                      {errors[`memberType_${member.id}`] && (
                        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors[`memberType_${member.id}`]}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        性别
                      </label>
                      <select
                        name={`memberGender_${member.id}`}
                        value={member.gender}
                        onChange={(e) => handleMemberChange(member.id, 'gender', e.target.value)}
                        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:text-white"
                      >
                        <option value="male">男</option>
                        <option value="female">女</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        年龄 <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="number"
                        name={`memberAge_${member.id}`}
                        value={member.age}
                        onChange={(e) => handleMemberChange(member.id, 'age', e.target.value)}
                        className="block w-full pl-3 pr-3 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:text-white"
                        min="0"
                        max="120"
                      />
                      {errors[`memberAge_${member.id}`] && (
                        <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors[`memberAge_${member.id}`]}</p>
                      )}
                    </div>
                  </div>

                  {formData.members.length > 1 && (
                    <div className="mt-3 text-right">
                      <button
                        type="button"
                        onClick={() => {
                          setFormData(prev => ({
                            ...prev,
                            members: prev.members.filter(m => m.id !== member.id)
                          }));
                        }}
                        className="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 text-sm"
                      >
                        <i class="fa-solid fa-trash mr-1"></i> 删除成员
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Siblings Information */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-4">
                兄弟姐妹信息
              </label>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    兄弟姐妹数量
                  </label>
                  <input
                    type="number"
                    name="siblingsCount"
                    value={formData.siblings.count}
                    onChange={handleSiblingsCountChange}
                    className="block w-full pl-3 pr-3 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:text-white"
                    min="1"
                    max="10"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    兄弟姐妹性别
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {Array.from({ length: formData.siblings.count }).map((_, index) => (
                      <select
                        key={index}
                        value={formData.siblings.genders[index]}
                        onChange={(e) => handleSiblingGenderChange(index, e.target.value)}
                        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:text-white"
                      >
                        <option value="male">男</option>
                        <option value="female">女</option>
                      </select>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
              <button
                type="button"
                onClick={() => navigate('/')}
                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <i class="fa-solid fa-arrow-left mr-2"></i> 返回首页
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <i class="fa-solid fa-spinner fa-spin mr-2"></i> 保存中...
                  </>
                ) : (
                  <>
                    下一步：父母自评
                    <i class="fa-solid fa-arrow-right ml-2"></i>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}