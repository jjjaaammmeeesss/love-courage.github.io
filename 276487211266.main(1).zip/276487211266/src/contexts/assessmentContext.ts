import { createContext } from "react";

// Define types for assessment data
type Dimension = 
  | "father_goal"    // 父系：目标与动机
  | "father_control" // 父系：内控与担当
  | "father_logic"   // 父系：逻辑与决断
  | "father_rule"    // 父系：规则与边界
  | "mother_empathy" // 母系：共情力
  | "mother_nurture" // 母系：滋养力
  | "mother_tolerate"// 母系：包容力
  | "mother_repair"  // 母系：修复力
  | "self_centered"; // 自我中心化

interface StoryAssessmentResult {
  answers: Record<string, {
    storyId: number;
    interactionId: number;
    dimension: Dimension;
    selectedOption: string;
    level: 1 | 2 | 3;
  }>;
  dimensionScores: Record<Dimension, number>;
  fatherScore: number;
  motherScore: number;
  selfCenteredScore: number;
  assessmentType: 'fatherStrong' | 'motherStrong' | 'balanced' | 'neglecting';
  timestamp: string;
}

export const AssessmentContext = createContext({
  assessmentData: {
    familyInfo: null as any,
    parentAssessment: null as any,
    storyAssessment: null as StoryAssessmentResult | null
  },
  saveFamilyInfo: (data: any) => {},
  saveParentAssessment: (data: any) => {},
  saveStoryAssessment: (data: StoryAssessmentResult) => {}
});